package com.microservices.comment.config;

public class RestTemplateConfig {

}
